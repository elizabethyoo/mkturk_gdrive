#include "mbed.h"
#include "ble/BLE.h"
Gap::ConnectionParams_t fast;

//BLENano pin definitions: https://developer.mbed.org/users/mbed_official/code/mbed-src/file/a11c0372f0ba/targets/hal/TARGET_NORDIC/TARGET_MCU_NRF51822/TARGET_RBLAB_BLENANO
DigitalOut led1(P0_19, 1); //pin 19, D13
DigitalOut ledpump(P0_19, 1); //pin 19, D13
DigitalOut pump_on(P0_28, 1); //pin 28, D4
DigitalOut serverping(P0_29, 1); //pin 28, D5

//InterruptIn tag_present_pin(P0_7); 
//DigitalOut rfid_reset(P0_6);
//Serial rfid_uart(P0_14,P0_29);

//DigitalOut myled1(P0_8, 1); //pin 8, D3
//DigittalOut myled2(P0_10, 1); //pin 10, D2
//DigitalOut myled3(P0_7, 1); //pin 7, D7

uint16_t customServiceUUID          = 0xA000; //Service
uint16_t writeUUID_connectionstatus = 0xA001; //Characteristic for connection status (write from javascript)
uint16_t writeUUID_pumpduration     = 0xA002; //Characteristic for pump on duration (write from javascript)
uint16_t readUUID_pumpstatus        = 0xA003; //Characteristic for pump status
uint16_t readUUID_rfidstatus        = 0xA004; //Characteristic for rfid reads

const static char     DEVICE_NAME[]        = "BLENano_PumpRFID_Zico"; // change based on device ID
static const uint16_t uuid16_list[]        = {0xFFFF}; //Custom UUID, FFFF is reserved for development

/* Set Up custom Characteristics */

//Connection Status (1 bit write)
static uint8_t connectionStatusValue[2] = {0};
//WriteOnlyArrayGattCharacteristic<uint8_t, sizeof(writeValue)> writeChar(writeCharUUID, writeValue);
//GattCharacteristic writeChar(writeCharUUID,writeValue,sizeof(writeValue),sizeof(writeValue),
//            GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_WRITE | GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_WRITE_WITHOUT_RESPONSE);
GattCharacteristic writeConnectionStatusChar(writeUUID_connectionstatus,
  connectionStatusValue,sizeof(connectionStatusValue),sizeof(connectionStatusValue),
  GattCharacteristic::GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_WRITE_WITHOUT_RESPONSE);

//Pump Duration (write)
static uint8_t pumpDurationValue[2] = {0};
//WriteOnlyArrayGattCharacteristic<uint8_t, sizeof(writeValue)> writeChar(writeCharUUID, writeValue);
//GattCharacteristic writeChar(writeCharUUID,writeValue,sizeof(writeValue),sizeof(writeValue),
//            GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_WRITE | GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_WRITE_WITHOUT_RESPONSE);
GattCharacteristic writePumpDurationChar(writeUUID_pumpduration,
  pumpDurationValue,sizeof(pumpDurationValue),sizeof(pumpDurationValue),
  GattCharacteristic::GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_WRITE_WITHOUT_RESPONSE);

//Pump Status (read)
static uint8_t pumpStatusValue[4] = {0};
//ReadOnlyArrayGattCharacteristic<uint8_t, sizeof(readValue)> readChar(readCharUUID, readValue);
GattCharacteristic readPumpStatusChar(readUUID_pumpstatus,
  pumpStatusValue,sizeof(pumpStatusValue),sizeof(pumpStatusValue),
  GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_READ | GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_NOTIFY);

//RFID Read
static uint8_t rfidValue[13] = {0};
GattCharacteristic readRFIDChar(readUUID_rfidstatus,
  rfidValue,sizeof(rfidValue),sizeof(rfidValue),
  GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_READ | GattCharacteristic::BLE_GATT_CHAR_PROPERTIES_NOTIFY);

/* Set up custom service */
GattCharacteristic *characteristics[] = {
    &writeConnectionStatusChar,
    &writePumpDurationChar,
    &readPumpStatusChar,
    &readRFIDChar,
};
GattService  customService(customServiceUUID, characteristics, sizeof(characteristics) / sizeof(GattCharacteristic *));

/* CALLBACK: Handle writes to writeCharacteristic */
void writeCharCallback(const GattWriteCallbackParams *params)
{
    /* Check to see what characteristic was written, by handle */
    if(params->handle == writePumpDurationChar.getValueHandle() |
        params->handle == writeConnectionStatusChar.getValueHandle()
        )
    {        
        short* pdatashort = (short*)(params->data);
        float dur = ((float)*pdatashort)/1000;

        printf("data in pointer = 0x");            
        printf("%d", *pdatashort);
        printf("\n\r");

        printf("dur %f", dur);
        printf("\n\r");

        /* Update the readChar with the value of writeChar */
        if (params->handle == writePumpDurationChar.getValueHandle()){
            printf("pump trigger\n\r");
            BLE::Instance(BLE::DEFAULT_INSTANCE).gattServer().write(readPumpStatusChar.getValueHandle(), params->data, params->len);
            ledpump = 0;
            pump_on = 1;            
            wait(dur);
            pump_on = 0;
            ledpump = 1;
        }
        if (params->handle == writeConnectionStatusChar.getValueHandle()){
            printf("connection ping\n\r");
            led1=0;
            serverping = 1;
            wait(dur);
            serverping = 0;
            led1=1;
        }
    }
}

//__________________Connection constants____________________________
/* how often to synchronize (send/receive) once connected,
client determines this, server can only suggest min/max values*/
//#define MIN_CONN_INTERVAL 250 //250 milliseconds
//#define MAX_CONN_INTERVAL 350 //350 milliseconds

/* how often server can ignore client requests when no new information available */
//#define SLAVE_LATENCY 4 // four events can be ignored, the fifth must be met

/* how long to wait for a data transfer before assuming disconnected*/
/* connection timeout should be greater than connection_interval 
client determines this, server can only suggest value */
//#define CONN_SUP_TIMEOUT 1000 // one second
//_________________________________________________________________

 
/*
 *  Restart advertising when phone app disconnects
*/
void disconnectionCallback(const Gap::DisconnectionCallbackParams_t *)
{
    BLE::Instance(BLE::DEFAULT_INSTANCE).gap().startAdvertising();
}

/*
 * Initialization callback
 */
void bleInitComplete(BLE::InitializationCompleteCallbackContext *params)
{
    BLE &ble          = params->ble;
    ble_error_t error = params->error;
    
    if (error != BLE_ERROR_NONE) {
        return;
    }

    ble.gap().onDisconnection(disconnectionCallback);
    ble.gattServer().onDataWritten(writeCharCallback);

    /* Setup advertising */
    ble.gap().accumulateAdvertisingPayload(GapAdvertisingData::BREDR_NOT_SUPPORTED | GapAdvertisingData::LE_GENERAL_DISCOVERABLE); // BLE only, no classic BT
    ble.gap().setAdvertisingType(GapAdvertisingParams::ADV_CONNECTABLE_UNDIRECTED); // advertising type
    ble.gap().accumulateAdvertisingPayload(GapAdvertisingData::COMPLETE_LOCAL_NAME, (uint8_t *)DEVICE_NAME, sizeof(DEVICE_NAME)); // add name
    ble.gap().accumulateAdvertisingPayload(GapAdvertisingData::COMPLETE_LIST_16BIT_SERVICE_IDS, (uint8_t *)uuid16_list, sizeof(uuid16_list)); // UUID's broadcast in advertising packet

    // Connection parameter that is controlled by server
    ble.gap().setAdvertisingInterval(25); // 20 ms to 1000 ms
    
    // Connection parameter suggetions that are controlled by the client
    ble.getPreferredConnectionParams(&fast);
    fast.minConnectionInterval = 8;
    fast.maxConnectionInterval = 16;
    fast.slaveLatency = 0;
    ble.setPreferredConnectionParams(&fast);

    /* Add our custom service */
    ble.addService(customService);

    /* Start advertising */
    ble.gap().startAdvertising();
}

/*
 *  Main loop
*/
int main(void)
{
    uint64_t X = us_ticker_read();

    /* initialize stuff */
    printf("\n\r********* Starting Main Loop *********\n\r");
        
    BLE& ble = BLE::Instance(BLE::DEFAULT_INSTANCE);
    ble.init(bleInitComplete);
    
    led1=1;
    pump_on=0;
    serverping=0;
    
    /* SpinWait for initialization to complete. This is necessary because the
     * BLE object is used in the main loop below. */
    while (ble.hasInitialized()  == false) { /* spin loop */ }

    /* Infinite loop waiting for BLE interrupt events */
    while (true) {
        ble.waitForEvent(); /* Save power */
    }
}